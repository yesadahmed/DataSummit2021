﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Model
{
	public class GenericModel
	{

		public string RemoteExecutionContext { get; set; }
	}
}
